import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLnJvYmlwdHY=')

name = b.b64decode('Um9iIElQVFY=')

host = b.b64decode('aHR0cDovL21lb3d5YXBtZW93LmNvbQ==')

port = b.b64decode('ODA4MA==')