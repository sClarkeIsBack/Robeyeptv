import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLnJvYmlwdHY=')

name = b.b64decode('Um9iIElQVFY=')

host = b.b64decode('aHR0cDovL2ZsYXdsZXNzLWlwdHYubmV0')

port = b.b64decode('NDU0NQ==')